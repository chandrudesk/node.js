const express = require('express');
const fileUpload = require('express-fileupload');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const app = express();

const {getHomePage} = require('./routes/index');
const {register,check,dashboard,editUser} = require('./routes/register');


app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(express.static('assets'));

// const {getHomePage} = require('./routes/index');
// const {addPlayerPage, addPlayer, deletePlayer, editPlayer, editPlayerPage} = require('./routes/player');
const port = 5000;

// create connection to database
// the mysql.createConnection function takes in a configuration object which contains host, user, password and the database name.
const db = mysql.createConnection ({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'nodeapp'
});

// connect to database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;

// configure middleware
app.set('port', process.env.port || port); // set express to use this port
//app.set('views', __dirname + '/views'); // set express to look in this folder to render our view
//app.set('view engine', 'ejs'); // configure template engine
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()); // parse form data client
app.use(express.static(path.join(__dirname, 'public'))); // configure express to use public folder
app.use(fileUpload()); // configure fileupload

// routes for the app
/*
app.get('/', getHomePage);
app.get('/add', addPlayerPage);
app.get('/edit/:id', editPlayerPage);
app.get('/delete/:id', deletePlayer);
app.post('/add', addPlayer);
app.post('/edit/:id', editPlayer);
*/

// set the app to listen on the port

app.get('/login',function(req, res){
	res.sendFile(__dirname+'/views/login.html');
	//res.send('Successfully Registered');
});

app.get('/dashboard',function(req, res){
	fetchdata(res);
});

app.get('/delete/:id',function(req, res){
	
	var id = req.params.id;
	
	let query = "DELETE FROM `user` WHERE id = "+id;
	//console.log(query); 
    db.query(query, (err, result) => {
	// 	var name = 'hello';
	 	//res.render(__dirname + "/views/dashboard.html");
	 	fetchdata(res);
	});
});

function fetchdata(res)
{
	let query = "SELECT * FROM `user` ORDER BY id ASC"; 
    db.query(query, (err, result) => {
		var name = 'hello';
		res.render(__dirname + "/views/dashboard.html", {name:name,result:result});
	});
}


app.get('/edit/:id',function(req, res){
	//res.send('Dashboard');
	var id = req.params.id;
	
	let query = "SELECT * FROM `user` WHERE id = "+id;
	//console.log(query); 
		

     db.query(query, (err, result) => {
	// 	var name = 'hello';
		// var name = result[0].name;
		// var mobile = result[0].mobile;
		// var email = result[0].email;
		// var password = result[0].password;
		// var confirm_password = result[0].confirm_password;
		if (err) {
                 return res.status(500).send(err);
             }
		//console.log(result[0]);
	 	res.render(__dirname + "/views/edit.html",{
	 		result:result[0]}
	 	);

	 	//fetchdata(res);
	});

})

app.get('/', getHomePage);
app.post('/add', register);
app.post('/check', check);
app.post('/update', editUser);

//app.get('/dashboard', dashboard);

app.listen(port, () => {
    console.log(`Server running on port: ${port}`);
});

