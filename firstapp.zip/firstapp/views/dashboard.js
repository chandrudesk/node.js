<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;    
}
</style>
</head>
<body>

<h2>User List</h2>
<!-- <% =message %> -->
<table style="width:100%">
  <tr>
    <th>S No</th>
    <th>Username:</th>
    <th>Mobile</th>
    <th>Email</th>
  </tr>
  

   <% users.forEach((user, dashboard) => { %>
   <tr>
        <td><%= user.name %></td>
        <td><%= user.mobile %></td>
        <td><%= user.email %></td>
      </tr>
    <% }) %>


<script> 
          //var result = [1,2,3,4,5,6,7];
      //$.each(players, function (i, currProgram) {
          for(let val of users) {
             console.log(val)
          }

      //});


 </script> 
</table>


<script src="app.js"></script>

</body>
</html>